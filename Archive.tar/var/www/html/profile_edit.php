
                              <form action="#" method="POST">
            <div class="panel-heading">
              <h3 class="panel-title">

  <input  style="width:auto;padding-left:5px" class="name_input" type="text" autocomplete="off" placeholder="<?php echo $_GET["fullname"]; ?>" name="username" value="<?php echo $_GET["fullname"];?>"/>
  <input style="padding-left:5px" class="name_input" type="text" autocomplete="off" placeholder="<?php echo $_GET["surname"]; ?>" name="surname" value="<?php echo $_GET["surname"]; ?>"/>
                        <div><input type="text"   name="username_copy" value="<?php echo $_GET["fullname"]; ?>" hidden/>
                        <input type="text"   name="surname_copy" value="<?php echo $_GET["surname"]; ?>" hidden/></div>
              </h3>
            </div>
            <div class="panel-body">
              <div class="row">
                <div class="col-md-3 col-lg-3 " align="center"> <img alt="User Pic" src="https://lh5.googleusercontent.com/-b0-k99FZlyE/AAAAAAAAAAI/AAAAAAAAAAA/eu7opA4byxI/photo.jpg?sz=100" class="img-circle"> </div>
                
              
                <div class=" col-md-9 col-lg-9 "> 
                  <table class="table table-user-information">
                    <tbody>
                      <tr>
                        <td>Email:</td>
                        <td><?php echo $_GET['email']; ?></td>
                        
                      </tr>
                      <tr>
                        <td>Телефон:</td>
                         <td><input class="" type="text" autocomplete="off" placeholder="<?php echo $_GET["phone"]; ?>" name="phone"/></td>
                        <td><input type="text"   name="phone_copy" value="<?php echo $_GET["phone"]; ?>" hidden/></td>
                      </tr>
                      <tr>
                        <td>Адрес</td>
                         <td><input class="" type="text" autocomplete="off" placeholder="<?php echo $_GET["address"]; ?>" name="address" /></td>
                       <td><input type="text"   name="address_copy" value="<?php echo $_GET["address"]; ?>" hidden/></td>
                      </tr>
                   
                         <tr>
                             <tr>
                        <td>Пол</td>
                        <td>Male</td>
                      </tr>
                        <tr>
                        <td>Компания</td>
                         <td><input class="" type="text" autocomplete="off" placeholder="<?php echo $_GET["company"]; ?>" name="company" /></td>
<td><input type="text"   name="company_copy" value="<?php echo $_GET["company"]; ?>" hidden/></td>
                      </tr>
                      <tr>
                        <td>Дата регистрации</td>
                        <td><?php echo $_GET['register_date']; ?></a></td>
                      </tr>
                        <td>Дата активации</td>
                        <td><?php echo $_GET['activation_date']; ?>
                        </td>
                             </tr>
                             <tr>
                           <td>Последнее время входа</td>
                        <td><?php echo $_GET['last_login_date']; ?>
                        </td>
                      </tr>
                     
                    </tbody>
                  </table>
                  
                  <!--a href="#" class="btn btn-primary">My Sales Performance</a>
                  <a href="#" class="btn btn-primary">Team Sales Performance</a-->
                </div>
              </div>
               <div class="panel-footer">
                        <!--input type="submit" data-original-title="Broadcast Message" data-toggle="tooltip"  class="btn btn-sm btn-primary"--><i class="glyphicon glyphicon-floppy-saved"></i> Сохранить<!--/input-->
                        
                    </div>
  </div>
         
         </form>