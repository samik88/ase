<?php
session_start();
include("functions.php");
/*
$phone_copy=$_POST['phone_copy'];
$address_copy=$_POST['address_copy'];
$company_copy=$_POST['company_copy'];
$phone=$_POST['phone'];
$address=$_POST['address'];
$company=$_POST['company'];
$username=$_POST['username'];
$surname=$_POST['surname'];
$username_copy=$_POST['username_copy'];
$surname_copy=$_POST['surname_copy'];





if(isset($phone_copy)&&isset($address_copy)&&isset($company_copy)&&isset($phone)&&isset($address)&&isset($company)&&isset($username)&&isset($surname)&&isset($username_copy)&&isset($surname_copy)){

    $sql="update users u set ";


   if(($username!=$username_copy)&&($username!="")){
    	$var[]=array();
     	$var[]="username";
     	$var[]=$username;
     	array_push($vars,$var);
        

	}


	if(($surname!=$surname)&&($surname!="")){
		$var[]=array();
        $var[]="surname";
        $var[]=$surname;
        array_push($vars,$var);
	}

	if(($phone_copy!=$phone)&&($phone!="")){
		$var[]=array();
		$var[]="phone";
		$var[]=$phone;
		array_push($vars,$var);

	}

	if(($address_copy!=$address)&&($address!="")){
		$var[]=array();
		$var[]="address";
		$var[]=$address;
		array_push($vars,$var);

	}

	if(($company_copy!=$company)&&($company!="")){
		$var[]=array();
		$var[]="company";
		$var[]=$company;
		array_push($vars,$var);

	}
	
echo sizeof($vars);
	if(sizeof($vars)>0){
		echo "4;";
		for($i=0;$i<$sizeof($vars)-1;$i++){
			$sql.=$vars[$i][0]."=".$vars[$i][1].", ";
		}
		echo "4;";
		echo $vars[0];
		echo $vars[sizeof($vars)-1];
    $sql.=$vars[sizeof($vars)-1][0]."=".$vars[sizeof($vars)-1][1]." ";
    echo $sql;
    $sql .="where email='".$_SESSION['email']."'";
	echo $sql;
	//update_user($sql);

	}
	
}

*/
?>

<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
<meta charset="utf-8"/>
<title>ASESHOPPIG</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<meta http-equiv="Content-type" content="text/html; charset=utf-8">
<meta content="" name="description"/>
<meta content="" name="author"/>
<!-- BEGIN GLOBAL MANDATORY STYLES -->
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css">
<link href="assets/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="assets/global/plugins/simple-line-icons/simple-lineicons.min.css" rel="stylesheet" type="text/css">
<link href="assets/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="assets/global/plugins/uniform/css/uniform.default.css" rel="stylesheet" type="text/css">
<link href="assets/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css"/>
<!-- END GLOBAL MANDATORY STYLES -->
<!-- BEGIN THEME STYLES -->
<link href="assets/global/css/components-rounded.css" id="style_components" rel="stylesheet" type="text/css"/>
<link href="assets/global/css/plugins.css" rel="stylesheet" type="text/css"/>
<link href="assets/admin/layout4/css/layout.css" rel="stylesheet" type="text/css"/>
<link id="style_color" href="assets/admin/layout4/css/themes/light.css" rel="stylesheet" type="text/css"/>
<link href="assets/admin/layout4/css/custom.css" rel="stylesheet" type="text/css"/>
<!-- END THEME STYLES -->
<link rel="shortcut icon" href="favicon.ico"/>
</head>
<script>
function ajaxFunc(str, id, fullname, surname, email, phone, address,register_date,activation_date,last_login_date){

if (window.XMLHttpRequest)
{
xmlhttp=new XMLHttpRequest();

}
else
{

xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");

}

xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 || xmlhttp.status==200)
{

document.getElementById(id).innerHTML=xmlhttp.responseText;

}
// document.getElementById(id).innerHTML=xmlhttp.responseText;

}

xmlhttp.open("GET",str+"?fullname="+fullname+"&surname="+surname+"&email="+ email+"&phone="+phone+"&address="+ address+"&register_date="+register_date+"&activation_date="+activation_date+"&last_login_date="+last_login_date,true);


xmlhttp.send(null);


}


</script>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="page-header-fixed page-sidebar-closed-hide-logo">
<!-- BEGIN HEADER -->
<div class="page-header navbar navbar-fixed-top">
	<!-- BEGIN HEADER INNER -->
	<div class="page-header-inner">
		<!-- BEGIN LOGO -->
		<div class="page-logo">
			<a href="index.html">
			<img src="public/logo.jpg" alt="logo" class="logo-default"/>
			</a>
			<div class="menu-toggler sidebar-toggler">
				<!-- DOC: Remove the above "hide" to enable the sidebar toggler button on header -->
			</div>
		</div>
		<!-- END LOGO -->
		<!-- BEGIN RESPONSIVE MENU TOGGLER -->
		<a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse">
		</a>
		<!-- END RESPONSIVE MENU TOGGLER -->
		<!-- BEGIN PAGE TOP -->
<?php if(isset($_SESSION['pincode'])){
?>
		<div class="page-top">
			<!-- BEGIN HEADER SEARCH BOX -->

			<!-- BEGIN TOP NAVIGATION MENU -->
			<div class="top-menu">
				<ul class="nav navbar-nav pull-right">
					<li class="separator hide">
					</li>
					<!-- BEGIN USER LOGIN DROPDOWN -->
					<!-- DOC: Apply "dropdown-dark" class after below "dropdown-extended" to change the dropdown styte -->
					<li class="dropdown dropdown-user dropdown-dark">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
						<span class="username username-hide-on-mobile">
						<?php echo "Добро пожаловать, ".$_SESSION['username'];?></span>
						<!-- DOC: Do not remove below empty space(&nbsp;) as its purposely used -->
						<img alt="" class="img-circle"/>
						</a>
						<ul class="dropdown-menu dropdown-menu-default">
							<li>
								<a href="profile.php">
								<i class="icon-user"></i> Мой профиль </a>
							</li>
							<li>
								<a href="logout.php">
								<i class="icon-key"></i> Выйти</a>
							</li>
						</ul>
					</li>
					<!-- END USER LOGIN DROPDOWN -->
				</ul>
			</div>

			<!-- END TOP NAVIGATION MENU -->
<?php }?>
		</div>
		<!-- END PAGE TOP -->
	</div>
	<!-- END HEADER INNER -->
</div>
<!-- END HEADER -->
<div class="clearfix">
</div>
<!-- BEGIN CONTAINER -->
<div class="page-container">

<?php if(isset($_SESSION['pincode'])){
?>
	<!-- BEGIN SIDEBAR -->
	<div class="page-sidebar-wrapper">
		<!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
		<!-- DOC: Change data-auto-speed="200" to adjust the sub menu slide up/down speed -->
		<div class="page-sidebar navbar-collapse collapse">
			<!-- BEGIN SIDEBAR MENU -->
			<!-- DOC: Apply "page-sidebar-menu-light" class right after "page-sidebar-menu" to enable light sidebar menu style(without borders) -->
			<!-- DOC: Apply "page-sidebar-menu-hover-submenu" class right after "page-sidebar-menu" to enable hoverable(hover vs accordion) sub menu mode -->
			<!-- DOC: Apply "page-sidebar-menu-closed" class right after "page-sidebar-menu" to collapse("page-sidebar-closed" class must be applied to the body element) the sidebar sub menu mode -->
			<!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
			<!-- DOC: Set data-keep-expand="true" to keep the submenues expanded -->
			<!-- DOC: Set data-auto-speed="200" to adjust the sub menu slide up/down speed -->
			<ul class="page-sidebar-menu " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200">
				<li>
					<a href="dashboard.php">
					<i class="icon-home"></i>
					<span class="title">Главная</span> 
					</a>
				</li>
				<li>
					<a href="orders.php">
					<i class="icon-bag"></i>
					<span class="title">Товары</span>
					</a>
				</li>
				<li>
					<a href="orders_view.php">
					<i class="icon-docs"></i>
					<span class="title">Оплаты</span>
					</a>
				</li>
				<li>
					<a href="howto.php">
					<i class="icon-info"></i>
					<span class="title">HOW-TO</span>
					</a>
				</li>				
				<li>
					<a href="faq.php">
					<i class="icon-question"></i>
					<span class="title">FAQ</span>
					</a>
				</li>	
				<li>
					<a href="contacts.php">
					<i class="fa fa-phone"></i>
					<span class="title">Контакты</span> 
					</a>
				</li>							
			</ul>
			<!-- END SIDEBAR MENU -->
		</div>
	</div>
	<!-- END SIDEBAR -->
	<!-- BEGIN CONTENT -->
	<div class="page-content-wrapper">
		<div class="page-content">
			<!-- BEGIN SAMPLE PORTLET CONFIGURATION MODAL FORM-->
			<div class="modal fade" id="portlet-config" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
							<h4 class="modal-title">Modal title</h4>
						</div>
						<div class="modal-body">
							 Widget settings form goes here
						</div>
						<div class="modal-footer">
							<button type="button" class="btn blue">Save changes</button>
							<button type="button" class="btn default" data-dismiss="modal">Close</button>
						</div>
					</div>
					<!-- /.modal-content -->
				</div>
				<!-- /.modal-dialog -->
			</div>
			<!-- /.modal -->
			<!-- END SAMPLE PORTLET CONFIGURATION MODAL FORM-->
			<!-- BEGIN PAGE HEADER-->
			<!-- BEGIN PAGE HEAD -->
			
			<!-- END PAGE HEAD -->
			<!-- END PAGE HEADER-->
			<!-- BEGIN PAGE CONTENT-->
			<div class="portlet light">
				<div class="portlet-body">
					<div class="row">
						<div class="col-md-12">
							<div class="row margin-bottom-20">
								
<div>

<div class="col-md-6">
									<div class="space20" >
										<?php	

			$result=user_list($_SESSION['email']);
			
        if (!is_array($result)){
		   while ($row = $result->fetch_assoc()) {?>
										
										<div class="panel panel-info" id="edit_panel">
											<!--form action="#" method="POST"-->
            <div class="panel-heading">
              <h3 class="panel-title"><?php echo $row['fullname'].' '.$row['surname'];?></h3>
            </div>
            <div class="panel-body">
              <div class="row">
                <div class="col-md-3 col-lg-3 " align="center"> <img alt="User Pic" src="https://lh5.googleusercontent.com/-b0-k99FZlyE/AAAAAAAAAAI/AAAAAAAAAAA/eu7opA4byxI/photo.jpg?sz=100" class="img-circle"> </div>
                
              
                <div class=" col-md-9 col-lg-9 "> 
                  <table class="table table-user-information">
                    <tbody>
                      <tr>
                        <td>Email:</td>
                        <td><?php echo $row['email']; ?></td>
                      </tr>
                      <tr>
                        <td>Телефон:</td>
                        <td><?php echo $row['phone']; ?></td>
                      </tr>
                      <tr>
                        <td>Адрес</td>
                        <td><?php echo $row['address']; ?></td>
                      </tr>
                   
                         <tr>
                             <tr>
                        <td>Пол</td>
                        <td>Male</td>
                      </tr>
                        <tr>
                        <td>Компания</td>
                        <td><?php echo $row['company']; ?></td>
                      </tr>
                      <tr>
                        <td>Дата регистрации</td>
                        <td><?php echo $row['register_date']; ?></a></td>
                      </tr>
                        <td>Дата активации</td>
                        <td><?php echo $row['activation_date']; ?>
                        </td>
                             </tr>
                             <tr>
                           <td>Последнее время входа</td>
                        <td><?php echo $row['last_login_date']; ?>
                        </td>
                      </tr>
                     
                    </tbody>
                  </table>
                  
                  <!--a href="#" class="btn btn-primary">My Sales Performance</a>
                  <a href="#" class="btn btn-primary">Team Sales Performance</a-->
                </div>
              </div>
                     </div>
                      <!--/form-->

                 <div class="panel-footer" style="height:50px"> 
                     
                        <span class="pull-right">
                            <a href="#"  onclick="ajaxFunc('profile_edit.php','edit_panel','<?php echo $row['fullname']?>','<?php echo $row['surname'];?>','<?php echo $row['email']; ?>','<?php echo $row['phone']; ?>','<?php echo $row['address']; ?>','<?php echo $row['register_date']; ?>','<?php echo $row['activation_date']; ?>','<?php echo $row['last_login_date']; ?>')" data-original-title="Edit this user" data-toggle="tooltip" type="button" class="btn btn-sm btn-warning"><i class="glyphicon glyphicon-edit"></i></a>
                            <a href="dashboard.php" data-toggle="tooltip" type="button" class="btn btn-sm btn-danger"><i class="glyphicon glyphicon-remove"></i></a>
                        </span>
                    </div>
            
         </div>
         
         <?php
     }
     }?>

</div>

								</div>
							</div>
						</div>
					</div>
				</div>
<?php }else{
    echo '<div style="min-height:300px; background-color:#fff;border-radius:5px;padding:15px;">';
	
    echo "Надо сначала <a href='http://my.aseshopping.com/login.php'>зайти</a> в систему</div>";
}?>
			</div>
			<!-- END PAGE CONTENT-->
		</div>
	</div>
	<!-- END CONTENT -->
		</div>
	</div>
	<!-- END CONTENT -->
</div>
<!-- END CONTAINER -->
<!-- BEGIN FOOTER -->
<div class="page-footer">
	<div class="page-footer-inner">
		 2015 &copy; ASESHOPPING.
	</div>
	<div class="scroll-to-top">
		<i class="icon-arrow-up"></i>
	</div>
</div>
<!-- END FOOTER -->
<!-- BEGIN JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
<!-- BEGIN CORE PLUGINS -->
<!--[if lt IE 9]>
<script src="assets/global/plugins/respond.min.js"></script>
<script src="assets/global/plugins/excanvas.min.js"></script> 
<![endif]-->
<script src="assets/global/plugins/jquery.min.js" type="text/javascript"></script>
<script src="assets/global/plugins/jquery-migrate.min.js" type="text/javascript"></script>
<!-- IMPORTANT! Load jquery-ui-1.10.3.custom.min.js before bootstrap.min.js to fix bootstrap tooltip conflict with jquery ui tooltip -->
<script src="assets/global/plugins/jquery-ui/jquery-ui-1.10.3.custom.min.js" type="text/javascript"></script>
<script src="assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js" type="text/javascript"></script>
<script src="assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
<script src="assets/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
<script src="assets/global/plugins/jquery.cokie.min.js" type="text/javascript"></script>
<script src="assets/global/plugins/uniform/jquery.uniform.min.js" type="text/javascript"></script>
<script src="assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
<!-- END CORE PLUGINS -->
<script src="assets/global/scripts/metronic.js" type="text/javascript"></script>
<script src="assets/admin/layout4/scripts/layout.js" type="text/javascript"></script>
<script src="assets/admin/layout4/scripts/demo.js" type="text/javascript"></script>
<script>
      jQuery(document).ready(function() {    
         Metronic.init(); // init metronic core components
Layout.init(); // init current layout
Demo.init(); // init demo features
      });
   </script>
<!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>

